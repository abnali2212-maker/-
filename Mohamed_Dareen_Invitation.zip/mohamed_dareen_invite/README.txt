Mohamed & Dareen wedding invitation

Open index.html to preview locally. Upload the complete folder contents to your GitHub Pages repository (keep the assets folder beside index.html).

The music.mp3 file is the audio extracted from the 60-second screen recording you supplied. The design is a close recreation based on that recording; it is not the original source code or original editable artwork from Mithaq.

Event: Sunday, 29 November 2026, 8:00 PM.
WhatsApp RSVP: +20 11 51454431
Map: https://maps.app.goo.gl/U94y2rCDRGeruW1f9?g_st=ac
